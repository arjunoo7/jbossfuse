GAuth Example
=============

Building, deploying and running this example is described in detail at
http://camel.apache.org/tutorial-oauth.html

Please help us make Apache Camel better - we appreciate any feedback you
may have.

Enjoy!

------------------------
The Camel riders!